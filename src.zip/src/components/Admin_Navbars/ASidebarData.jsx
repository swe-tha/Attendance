import React from "react";
import * as IoIcons from "react-icons/io";

 
export const SidebarData = [

  {
    title: "Employee Profile",
    path: "/Employee_All",
    icon: <IoIcons.IoIosPerson />,
  },
  {
    title: "AttendanceRecord",
    path: "/Attendance_View",
    icon: <IoIcons.IoIosPaper />, 
  },

  {
    title: "Manage Leave",
    path: "/Vp",
    icon: <IoIcons.IoIosLeaf />,

  },
  
  {
    title: "Add Employee",
    path: "/AddEmployee",
    icon: <IoIcons.IoIosPersonAdd />,

  },
  {
    title: "General",
    path: "/Sidebar",
    icon: <IoIcons.IoIosPersonAdd />,

  },
  
 
];
export default SidebarData;