import React, { Component } from "react";
import Flippy, { FrontSide, BackSide } from 'react-flippy';
import ACharts from './ACharts'
import ALineChart from './ALineChart'
import ASidebar from './ASidebar'

export default class Dashboard extends Component{
    render(){
        return (
            <>
        
 <ASidebar/>
<div className="row" style={{marginLeft:"200px"}}> 

<Flippy
    flipOnHover={false} // default false
    flipOnClick={true} // default false
    flipDirection="horizontal" // horizontal or vertical
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px', marginRight:"50px"}} 
  >
    <FrontSide
      style={{
        backgroundColor: ' #e6e6e6',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Total Number</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: '#ff9966'}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>1000</div>
    </BackSide>
  </Flippy>


    <Flippy
    flipOnHover={false} // default false
    flipOnClick={true} // default false
    flipDirection="horizontal" // horizontal or vertical
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px', marginLeft:"10px",marginRight:"50px"}} 
  >
    <FrontSide
      style={{
        backgroundColor: ' #e6e6e6',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Employee Online</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: '#ff9966'}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>1000</div>
    </BackSide>
  </Flippy>


  <Flippy
    flipOnHover={false} 
    flipOnClick={true} 
    flipDirection="horizontal" 
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px',marginRight:"50px" }} >
    <FrontSide
      style={{
        backgroundColor: '#ff9966',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Employee InActive</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: ' #e6e6e6'}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>1000</div>
    </BackSide>
  </Flippy>

  <Flippy
    flipOnHover={false} // default false
    flipOnClick={true} // default false
    flipDirection="horizontal" // horizontal or vertical
    ref={(r) => this.flippy = r} 
    style={{ width: '200px', height: '150px' }} 
  >
    <FrontSide
      style={{
        backgroundColor: ' #e6e6e6',
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Employee On Leave</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: '#ff9966'}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>1000</div>
    </BackSide>
  </Flippy>

  <div className="row col-md-12 mt-5">Attendance Report
  <div className="col-md-5 mt-5 mr-3 card"><ACharts/ ></div>
  <div className="col-md-5 mt-5 card"><ALineChart/ ></div>
  {/* <div className="col-md-3 mt-5 ml-5" style={{ width: '16rem',  marginTop:""}}>
    <Flippy className="card ml-4 " style={{ width: '16rem' }}
    flipOnHover={false} 
    flipOnClick={true} 
    flipDirection="vertical" 
    ref={(r) => this.flippy = r}
    style={{ width: '200px', height: '150px' }} 
  >
    <FrontSide
      style={{
        backgroundColor:'#ff9966' ,
      }}
    >
      <div className="text-center" style={{marginTop:"40px"}}>Leave</div>
    </FrontSide>
    <BackSide
      style={{ backgroundColor: '#e6e6e6'}}>
      <div style={{marginTop:"40px",marginLeft:"60px"}}>1000</div>
    </BackSide>
  </Flippy>
    </div> */}
</div>
      </div>      
 
            </>
        )
    }
}