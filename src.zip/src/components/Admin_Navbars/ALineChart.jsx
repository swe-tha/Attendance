import React from 'react';
import {Doughnut} from 'react-chartjs-2';
const data = {
  labels: [
    'Active',
    'InActive',
    'OnLeave'
  ],
  datasets: [{
    data: [300, 50, 100],
    backgroundColor: [
    '#80d4ff',
    '#ff66b3',
    '#FFCE56'
    ],
    hoverBackgroundColor: [
    '#80d4ff',
    '#ff66b3',
    '#FFCE56'
    ]
  }]
};
function ALineChart() {
  return (
    <div>
        
        <Doughnut data={data} />
    </div>
  );
}
export default ALineChart;