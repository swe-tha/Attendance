import 'bootstrap/dist/css/bootstrap.min.css'
import './Login.css'
import{Link,Redirect} from "react-router-dom"
import {useEffect,useState} from 'react'

export default function Login (){
    const [dayPart, setD]=useState('');
    const [userId, setUser]=useState('');
    const [password, setPassword]=useState('');
    const [result, setResult]=useState('');
    const [login, setLogin]=useState('');
    
    useEffect(()=> {
      console.log("....."+userId);
      localStorage.setItem('UserId',userId)
    },[userId])

    
  
    useEffect(()=> {
      var today = new Date();
      var time = today.getHours();
    
      if(time <12)
        setD('Good Morning');
      else if(time <18)
        setD('Good Afternoon');
      else
        setD('Happy Evening');
    },[])

  
  function changeUser(event){
    setUser(event.target.value);
  }
  function changePassword(event){
    setPassword(event.target.value);
  }

  


  function submitForm() {
      
      var isAdmin="";
      fetch("http://localhost:8765/attendance/login",{
        method:"POST",
        mode:"cors",
        body:JSON.stringify({
          "empId":userId,
          "password":password
        }),
        headers:{
          "Content-Type" : "application/json",
          "Accept":"application/json"
        }
      }).then(response=>{
        if(response.ok){
          response.text().then(json=>{
            isAdmin=json;
            console.log(isAdmin)

            if(isAdmin==="YES" )
            {
              setLogin("t");
              setResult('Logged In Successfully')

            }

            else if(isAdmin==="NO")
            {
                setLogin("n")
                setResult('Logged In Successfully')
            }
              
            else
                setResult('UserName or Password is Incorrect')
            

          })
        }
      }).catch(error=>{
        console.log("Error",error)
      })
      
     return isAdmin; 

  }
  
 

  return(
      <>
      <div className="row">
          <div className="col-md-6 col-lg-6">
          <img className="login_image"
          src="https://www.naceweb.org/uploadedImages/images/2019/feature/the-four-career-competencies-employers-value-most.jpg
          " alt='login_poster'/> </div>
       
          <div className="col-md-6">
            <div className="login_card">
                    
              <h3 style={{paddingTop:"50px",paddingBottom:"25px"}}>Welcome Back!!</h3>
              {dayPart} User
              <br/><br/>
                      
              <form>
                <div className="form-group">
                <input type="text"  onChange= {(e) =>changeUser(e)} placeholder="Enter userId" required/>
                </div>
                      
                <div className="form-group">
                <input type="password" onChange={(e) =>changePassword(e)} placeholder="Enter password" required/>
                </div>
                

                      
                  
                <button type="button" className="login_btn" onClick= {()=>submitForm()  }>Login </button><br/><br></br> <br/>
                <Link to="/FirebaseApp"><button type="button" className="login_btn"  >Forget Password </button><br/><br/>
                </Link>
                
                <span className="text-danger" style={{display:"block"}}>{result}</span>
                  
                </form>
                {login==="t"?<Redirect to="/ASidebar"></Redirect>:(<>{login==="n"?<Redirect to="/Sidebar"></Redirect>:<></>}</>)}

                </div>

                </div>
        </div>
      
      </>
  )
}
