// import SidebarData from './src/components/Navbars/SidebarData'
// import SubMenu from './src/components/Navbars/SubMenu'
// import Sidebar from './src/components/Navbars/Sidebar'
import React, { Component } from "react";
import {Link} from 'react-router-dom'
import MyAttendance from './MyAttendance'

export default class I_Attendance extends Component{
    render(){
        return (
            <>
            <h1>Hi admin</h1>
            {/* <Sidebar/> */}
            <MyAttendance/>
            </>
        )
    }
}