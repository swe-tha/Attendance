import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableContainer from '@material-ui/core/TableContainer';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import Card from "react-bootstrap/Card";
// import Sidebar from '../Navbars/Sidebar'



const useStyles = makeStyles({
  table: {
    maxWidth: 350,
    
  },
  
});

function ccyFormat(num) {
  return `${num.toFixed(2)}`;
}

function priceRow(qty, unit) {
  return qty - unit;
}

function createRow(desc, qty, unit) {
  const price = priceRow(qty, unit);
  return { desc, qty, unit, price };
}

function subtotal(items) {
  return items.map(({ price }) => price).reduce((sum, i) => sum + i, 0);
}
const rows = [
  createRow('Compensatory Off', 10, 8),
  createRow('Marriage Leave', 7, 0),
  createRow('LOP',20, 17.99),
  createRow('CasualLeave', 10, 17.99),
  createRow('SickLeave', 10, 17.99),
  createRow('Maternity/Paternity Leave', 60, 0),
  createRow('Annual', 15, 7),

];

const invoiceSubtotal = subtotal(rows);
// const invoiceTaxes = TAX_RATE * invoiceSubtotal;
const invoiceTotal = 100 - invoiceSubtotal;

export default function SpanningTable() {
  const classes = useStyles();

  return (
    <>
    {/* <Sidebar/> */}
    <Card.Body>
            <Card.Title>Leave Records</Card.Title>
        </Card.Body>
    <TableContainer component={Paper}>
      <Table className={classes.table} aria-label="spanning table">
        <TableHead>
          
          <TableRow style={{color:"black"}}>
            <TableCell>Desc</TableCell>
            <TableCell align="right">No.of.Leaves Avail</TableCell>
            <TableCell align="right">No.of.leaves Taken</TableCell>
            <TableCell align="right">Remaining Leave</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.desc}>
              <TableCell>{row.desc}</TableCell>
              <TableCell align="right">{row.qty}</TableCell>
              <TableCell align="right">{row.unit}</TableCell>
              <TableCell align="right">{ccyFormat(row.price)}</TableCell>
            </TableRow>
          ))}

          <TableRow>
            <TableCell rowSpan={3} />
            <TableCell colSpan={2}>Subtotal</TableCell>
            <TableCell align="right">{ccyFormat(invoiceSubtotal)}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell>Total Leaves</TableCell>
            <TableCell align="right"></TableCell>
            <TableCell align="right">{100}</TableCell>
          </TableRow>
          <TableRow>
            <TableCell colSpan={2}>Total</TableCell>
            <TableCell align="right">{ccyFormat(invoiceTotal)}</TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </TableContainer>
    </>
  );
}
