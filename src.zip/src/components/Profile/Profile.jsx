import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Button from "@material-ui/core/Button";
import "bootstrap/dist/css/bootstrap.min.css";
import AddAPhotoIcon from "@material-ui/icons/AddAPhoto";
import AccountBoxIcon from "@material-ui/icons/AccountBox";
import PinDropIcon from "@material-ui/icons/PinDrop";
import DesktopWindowsIcon from "@material-ui/icons/DesktopWindows";
import ContactMailIcon from "@material-ui/icons/ContactMail";
import Sidebar from '../Navbars/Sidebar'

import {useState,useEffect} from 'react'

const useStyles = makeStyles((theme) => ({
  root: {
    display: "flex",
    flexWrap: "wrap",
    "& > *": {
      margin: theme.spacing(1),
      width: theme.spacing(16),
      height: theme.spacing(16)
    }
  }
}));


export default function SimplePaper() {
  const classes = useStyles();
  const [details, setDetails]=useState([])
  // const ListLoading = withListLoading(List);
  
  
  useEffect(()=>{
  fetch("http://localhost:8765/attendance/getemployee/"+localStorage.getItem("UserId"))
    .then((response)=> response.json())
    .then((json)=>{
        console.log("nnnn",json);
        setDetails(json);
      },
      )},[]) 
  

  return (
    <div>
    <Sidebar/>
    <div className={classes.root}>
    
      <Paper
        elevation={3}
        style={{ marginLeft: 250, marginTop: 100, width: 250, height: 170 }}
      >
        <AccountBoxIcon
          style={{ fontSize: 100, color: " #ff9980" }}
        ></AccountBoxIcon>
        <p
          style={{
            fontFamily: "Times New Roman",
            marginLeft: 20,
            fontSize: 25
          }}
        >
          {details.empName}
        </p>
      </Paper>
      <Paper
        elevation={3}
        style={{ marginTop: 100, width: 250, height: 170, marginLeft: 50 }}
      >
        <PinDropIcon style={{ fontSize: 90, color: " #ff9980" }}></PinDropIcon>
        <p
          style={{
            fontFamily: "Times New Roman",
            marginLeft: 20,
            fontSize: 25
          }}
        >
          Mysore
        </p>
      </Paper>
      <Paper
        elevation={3}
        style={{ marginTop: 300, marginLeft: -560, width: 250, height: 200 }}
      >
        <DesktopWindowsIcon
          style={{ fontSize: 80, margin: 10, color: " #ff9980" }}
        ></DesktopWindowsIcon>
        <p
          style={{
            fontFamily: "Times New Roman",
            marginLeft: 20,
            fontSize: 25
          }}
        >
          {details.jobRole}
        </p>
      </Paper>
      <Paper
        elevation={3}
        style={{ marginTop: 300, width: 250, height: 200, marginLeft: 50 }}
      >
        <ContactMailIcon
          color="primary"
          style={{ fontSize: 90, margin: 10, color: " #ff9980" }}
        ></ContactMailIcon>
        <p
          style={{
            fontFamily: "Times New Roman",
            marginLeft: 10,
            fontSize: 20
          }}
        >
          {details.email}
        </p>
        <p
          style={{
            fontFamily: "Times New Roman",
            marginLeft: 10,
            fontSize: 20
          }}
        >
          {details.mobileNo}
        </p>
      </Paper>
      <Paper
        elevation={3}
        style={{ width: 250, marginTop: 120, height: 260, marginLeft: 110 }}
      >
        <img
          src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS38zu52WbPVB1MolgBHgBo9YBigWNHTjPYOw&usqp=CAU"
          alt="emp"
          style={{ width: 250, height: 260 }}
        />

        <Button style={{ widht: 10 }}>
          <AddAPhotoIcon
            color="primary"
            style={{
              marginLeft: 100,
              marginTop: -30,
              width: 50,
              fontSize: 150,
              color: "#ff6600"
            }}
          ></AddAPhotoIcon>
        </Button>
      </Paper>
    </div>
    </div>
  );
}