import React, { Component } from "react";
import Switch from "react-switch";


// import {browserHistory} from "react-router-dom";

class Selection extends Component {
  constructor() {
    super();
    this.state = { checked: false };
    this.handleChange = this.handleChange.bind(this);
  }

  handleChange(checked) {
    this.setState({ checked });
    
  }


  render() {
    return (
      <div>
      {/* {this.state.checked?<ASidebar/>:<Sidebar/>} */}
      <label>
       
        <label className="mt-1"> Employee</label>
        <Switch
    checked={this.state.checked}
    onChange={this.handleChange}
    onColor="#86d3ff"
    onHandleColor="#2693e6"
    handleDiameter={20}
    uncheckedIcon={false}
    checkedIcon={false}
    boxShadow="0px 1px 5px rgba(0, 0, 0, 0.6)"
    activeBoxShadow="0px 0px 1px 10px rgba(0, 0, 0, 0.2)"
    height={15}
    width={35}
    className="react-switch"
    id="material-switch"
  />
  <label>Admin</label>
      </label>
    </div>  
    );
  }
}
export default Selection;