import React, { useState } from "react";
import styled from "styled-components";
import { NavLink,Link } from "react-router-dom";
import {NavDropdown} from 'react-bootstrap';

import * as FaIcons from "react-icons/fa";

import { SidebarData } from "./SidebarData";
import SubMenu from "./SubMenu";


import { IconContext } from "react-icons/lib";

  
const Nav = styled.div`

  height: 65px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;


const NavIcon = styled(Link)`
  margin-left: 2rem;
  font-size: 1rem;
  height: 80px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
`;
  
const SidebarNav = styled.nav`
  
  background: linear-gradient(to bottom, #ffffff 0%, #ff9966 100%);
  width: 150px;
  height: 100vh;
  display: flex;
  justify-content: center;
  position: fixed;
  top: 0;
  z-index: 10;
`;
  
const SidebarWrap = styled.div`
  width: 100%;`;
  
const Sidebar = () => {
  const [sidebar, setSidebar] = useState(false);
  const showSidebar = () => setSidebar(!sidebar); 
  return (
    <>
      <IconContext.Provider value={{ color: "black" }}>
        <Nav>
          <NavIcon to="#">
          <FaIcons.FaBars onClick={showSidebar} />
          </NavIcon>
          <div style={{ textAlign: "center", 
                     marginLeft: "150px",
                     color:"#ff5500",
                    size:"20px",}}> INFOSYS ATTENDANCE PORTAL </div> 
          
          <NavDropdown title={localStorage.getItem("UserId")}style={{marginLeft:"625px"}}>
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/ContactUs" exact>Contact</NavLink></NavDropdown.Item>
            {/* <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/aboutus" exact> About </NavLink></NavDropdown.Item> */}
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/changepassword" exact> Change Password</NavLink></NavDropdown.Item>
            <NavDropdown.Item><NavLink className="navbar-item" activeClassName="is-active" to="/logout" exact> Logout</NavLink></NavDropdown.Item>
          </NavDropdown>
         
        </Nav>
        <SidebarNav sidebar={sidebar}>

          <SidebarWrap> 
          <img className="transparent" style={{width:"125px",height:"50px",marginTop:"10px",marginLeft:"10px"}} src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/95/Infosys_logo.svg/200px-Infosys_logo.svg.png" alt='logo of infosys'/>
          <div></div>
            {SidebarData.map((item, index) => {
              return <SubMenu item={item} key={index} />;
            })}
          </SidebarWrap>

        </SidebarNav>
      </IconContext.Provider>
      
    </>
  );
};
  
export default Sidebar;