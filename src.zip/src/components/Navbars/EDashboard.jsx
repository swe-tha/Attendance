import React from "react";
import Sidebar from "./Sidebar"
  
export const EDashboard = () => {
  return (
    <>
    <Sidebar/>
    <div className="home" style={{marginLeft:"200px"}}>
      <div><h6 style={{color:"blue"}}>Welcome, Infoscion!</h6>
      <p style={{fontFamily:"cursive",fontSize:"20px",color:"red"}}>Guidelines:</p>
      <p style={{fontSize:"12px"}}>1. Total hours worked will comprise of the actual time spent in company as well as approved Work From Home (WFH) and on duty hours spent on all working days. Approved WFHs and ODs on non-working days will also be included.</p>
      <p style={{fontSize:"12px"}}>2. Total hours worked will also comprise of the hours worked on the weekends or public holidays, once the compensatory-off is approved.</p>
      <p style={{fontSize:"12px"}}>3. You can view your attendance and also the number of working hours.Punch, even when you go on a break, so that your working hours will not be affected beacause of break</p>
      <p style={{fontSize:"12px"}}>4. Apply for leave as earlier as possible, so that admin can accept your leave on time. Else, it will be rejected if not informed earlier.</p>
      <p style={{fontSize:"12px"}}>5. Un-approved status unknown days and un-approved single swipe days will not be considered as a working day.</p>
      <p style={{fontSize:"12px"}}>6. All declared Holidays, weekly offs and every leave types will be considered as non-working days and are not taken into account for calculating average hours of an employee.</p>
      <p style={{fontSize:"12px"}}>7. For any average hours calculation related queries, please contact admin.</p>
    </div>
    </div>
    </>
    
  );
  
};
export default EDashboard;
  
