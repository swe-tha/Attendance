import React, { Component } from 'react';
import PropTypes from 'prop-types';
import ChatBot from 'react-simple-chatbot';
// import './Chatbot.css';
import { ThemeProvider } from 'styled-components';


const theme = {
  background: '#f5f8fb',
  fontFamily: 'Helvetica Neue',
  headerBgColor: '#EF6C00',
  headerFontColor: '#fff',
  headerFontSize: '15px',
  botBubbleColor: '#EF6C00',
  botFontColor: '#fff',
  userBubbleColor: '#fff',
  userFontColor: '#4a4a4a',
};
class Review extends Component {
  constructor(props) {
    super(props);

    this.state = {
      name: '',
      type: '',
      age: '',
      days:'',
      empId:''
    };
  }

  componentWillMount() {
    const { steps } = this.props;
    const { name, type, days,empId} = steps;

    this.setState({ name, type,days,empId});
  }

  render() {
    
    const { name, type, days,empId } = this.state;
    return (
      <div style={{ width: '100%' }}>
        <h3>Summary</h3>
        <table>
          <tbody>
            <tr>
              <td>Name</td>
              <td>{name.value}</td>
            </tr>
            <tr>
              <td>Gender</td>
              <td>{type.value}</td>
            </tr>
            <tr>
              <td>Days</td>
              <td>{days.value}</td>
            </tr>
            <tr>
              <td>EmpId</td>
              <td>{empId.value}</td>
            </tr>
          </tbody>
        </table>
      </div>
    );
  }
}

Review.propTypes = {
  steps: PropTypes.object,
};

Review.defaultProps = {
  steps: undefined,
};

class SimpleForm extends Component {
  render() {
    return (
      // <div className="chatbot">
      <ThemeProvider theme={theme}>
      <ChatBot
        steps={
          [
          {
            id: '1',
            message: 'What is your name?',
            trigger: 'name',
          },
          {
            id: 'name',
            user: true,
            trigger: '3',
          },
          {
            id: '3',
            message: 'Hi {previousValue}! Your Query Please!!',
            trigger: 'type',
          },
          {
            id: 'type',
            options: [
              { value: 'attendance', label: 'Attendance Query', trigger: '5' },
              { value: 'leave', label: 'Leave Query', trigger: '5' },
            ],
          },

          

          {
            id: '5',
            message: 'How long?',
            trigger: 'days',
          },
          {
            id: 'days',
            user: true,
            trigger: '7',
            validator: (value) => {
              if (isNaN(value)) {
                return 'value must be a number';
              }
              return true;
            },
          },

          {
            id: '7',
            message: 'May I know your Employee ID?',
            trigger: 'empId',
          },
          {
            id: 'empId',
            user: true,
            trigger: '9',
            validator: (value) => {
              if (isNaN(value)) {
                return 'value must be a number';
              }
              return true;
            },
            
          },

          {
            id: '9',
            message: 'Great! Check out your summary',
            trigger: 'review',
          },
          {
            id: 'review',
            component: <Review />,
            asMessage: true,
            trigger: 'update',
          },
          {
            id: 'update',
            message: 'Would you like to update some field?',
            trigger: 'update-question',
          },
          {
            id: 'update-question',
            options: [
              { value: 'yes', label: 'Yes', trigger: 'update-yes' },
              { value: 'no', label: 'No', trigger: 'end-message' },
            ],
          },
          {
            id: 'update-yes',
            message: 'What field would you like to update?',
            trigger: 'update-fields',
          },
          {
            id: 'update-fields',
            options: [
              { value: 'name', label: 'Name', trigger: 'update-name' },
              { value: 'type', label: 'type', trigger: 'update-type' },
              { value: 'days', label: 'days', trigger: 'update-days' },
            ],
          },
          {
            id: 'update-name',
            update: 'name',
            trigger: '9',
          },
          {
            id: 'update-type',
            update: 'gender',
            trigger: '9',
          },
          {
            id: 'update-days',
            update: 'days',
            trigger: '9',
          },
          
          {
            id: 'end-message',
            message: 'Thanks! Your data was submitted successfully!!  If urgent Contact admin through Call!!! Contact Number : 9898789890 ',
            end: true,
          },
          
          
         
        ]

        
      }
      />
      
    {/* <ChatBot steps={steps} />; */}
  </ThemeProvider>
    //  </div>
    );
  }
}

export default SimpleForm;