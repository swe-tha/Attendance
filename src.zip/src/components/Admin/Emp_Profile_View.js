import React, { Component } from "react";
import Sidebar from '../Navbars/Sidebar';
import {Link} from 'react-router-dom';


export default class Emp_Profile extends Component{

  constructor(props){
    super(props);
    this.state={
      data:[],
      isLoaded:true,
      isError:false,
      output:[],
      formValue:{
        empName:"",
        email:"",
        jobRole:"",
        department:"",
        mobileNo:"",
        results:[]
        }
      
    }
  }

  async componentDidMount(){
    this.setState({isLoading:true})
    const response= await fetch("http://localhost:8765/attendance/getemployee/"+localStorage.getItem("UserId"));
    if(response.ok){
      const data=await response.json()
      this.setState({data:data,isLoading:false})
      console.log(data);

    }
    else{
      this.setState({iserror:true,isLoading:false})
    }
  }

  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
  }

  handleSubmit=(event)=>{
    event.preventDefault();
  }

  save=()=>{
    var isAdmin="";
    fetch("http://localhost:8765/attendance/employeedetails/"+localStorage.getItem("UserId"),{
      method:"PUT",
      mode:"cors",
      body:JSON.stringify({
        "empName":this.state.formValue.empName,
        "email":this.state.formValue.email,
        "jobRole":this.state.formValue.jobRole,
        "department":this.state.formValue.jobRole,
        "mobileNo":this.state.formValue.mobileNo

      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json"
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          isAdmin=json;
          console.log("Checkout",isAdmin)
          this.setState({
            output:json
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })

  }


render(){
  return (
  <>         
   {/* {this.state.checked?<ASidebar/>:<Sidebar/>} */}
   <Sidebar/>
    <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
   
    <div className='ml-5'>
    <div style={{ width: 600, marginTop: 20}} type='info' className="col-md-12 ">
      <div className="card-body">
      <div className="topic" style={{paddingBottom:"20px"}}>Edit Details </div>
         <div class="form-group" style={{marginLeft:"50px"}} >
         <form onSubmit={this.handleSubmit}>
         <label> Employee Id</label>
          <input type="text" name="empId" value={this.state.data.empId} onChange={this.handleChange} className="form-control " /> <br />
          <label> Given Name</label>
          <input type="text" name="empName" placeholder={this.state.data.empName} onChange={this.handleChange}  className="form-control" /> <br />
          Email:<input type="email" id="email" placeholder={this.state.data.email} name="email" onChange={this.handleChange} className="form-control" /> <br />
          
          <label> Department</label>
          <input type="text" name="department" placeholder={this.state.data.department} onChange={this.handleChange}  className="form-control" /> <br />
          <label> JobRole</label>
          <input type="text" name="jobRole" placeholder={this.state.data.jobRole} onChange={this.handleChange} className="form-control" /> <br />
          <label> Mobile No</label>
          <input type="text" name="mobileNo" placeholder={this.state.data.mobileNo} onChange={this.handleChange} className="form-control" /> <br />
          
        </form></div>
      </div>
      <div style={{marginLeft:"50px"}}>
        <button className="attr_btn ml-4 mr-5" onClick= {this.save} type="submit" >Save</button>
        
      </div>
    </div>

  </div>
  <div >
    <div >
      
      
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT7R1-iBTMTHEyl99YywmKIg6nL7a2vV24bqQ&usqp=CAU" alt='some value' className="mt-5" />
      <div className="cardBody">
        <p>{this.state.data.empName} </p>
      </div>
      
        <button className="attr_btn">Edit</button>
        <Link to="/Profile"><button className="attr_btn">View</button></Link>
   
    </div>

  </div>
</div>
            </>
        )
    }
}