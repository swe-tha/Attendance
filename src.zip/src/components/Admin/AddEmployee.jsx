import React, { Component } from "react";
import ASidebar from '../Admin_Navbars/ASidebar';



export default class Add_Employee extends Component{

  constructor(props){
    super(props);
    this.state={
      data:[],
      isLoaded:true,
      isError:false,
      output:[],
      formValue:{
          empId:"",
        empName:"",
        email:"",
        jobRole:"",
        department:"",
        mobileNo:"",
        password:"",
        status:"",
        isAdmin:"",
        results:[]
        }
      
    }
  }



  handleChange=(event)=>{
    var name=event.target.name
    var value=event.target.value
    var {formValue}=this.state
    this.setState({formValue :{...formValue,[name]:value}})
  }

  handleSubmit=(event)=>{
    event.preventDefault();
  }

  save=()=>{
    var isAdmin="";
    fetch("http://localhost:8765/attendance/employee",{
      method:"POST",
      mode:"cors",
      body:JSON.stringify({
        "empId":this.state.formValue.empId,
        "empName":this.state.formValue.empName,
        "password":this.state.formValue.password,
        "jobRole":this.state.formValue.jobRole,
        "email":this.state.formValue.email,
        
        "department":this.state.formValue.department,
        "status":this.state.formValue.status,
        "mobileNo":this.state.formValue.mobileNo,
        
        "isAdmin":this.state.formValue.isAdmin


      }),
      headers:{
        "Content-Type" : "application/json",
        "Accept":"application/json"
      }
    }).then(response=>{
      if(response.ok){
        response.text().then(json=>{
          isAdmin=json;
          console.log(isAdmin)
          this.setState({
            output:json
          })
        })
      }
    }).catch(error=>{
      console.log("Error",error)
    })

  }


render(){
  return (
  <>         
   {/* {this.state.checked?<ASidebar/>:<Sidebar/>} */}
   <ASidebar/>
    <div style={{ display: 'flex', justifyContent: 'space-evenly' }}>
   
    <div className='ml-5'>
    <div style={{ width: 600, marginTop: 20}} type='info' className="col-md-12 ">
      <div className="card-body">
      <div className="topic" style={{paddingBottom:"20px"}}>Add Employee</div>
         <div class="form-group" style={{marginLeft:"50px"}} >
         <form onSubmit={this.handleSubmit}>
         <label> Employee Id</label>
          <input type="text" name="empId" value={this.state.data.empId} onChange={this.handleChange} className="form-control " /> <br />
          <label> Given Name</label>
          <input type="text" name="empName" placeholder={this.state.data.empName} onChange={this.handleChange}  className="form-control" /> <br />
          <label>Password</label>
          <input type="password" name="password" placeholder={this.state.data.password} onChange={this.handleChange}  className="form-control" /> <br />
          Email:<input type="email" id="email" placeholder={this.state.data.email} name="email" onChange={this.handleChange} className="form-control" /> <br />
          
          <label> Department</label>
          <input type="text" name="department" placeholder={this.state.data.department} onChange={this.handleChange}  className="form-control" /> <br />
          <label> JobRole</label>
          <input type="text" name="jobRole" placeholder={this.state.data.jobRole} onChange={this.handleChange} className="form-control" /> <br />
          <label> Mobile No</label>
          <input type="text" name="mobileNo" placeholder={this.state.data.mobileNo} onChange={this.handleChange} className="form-control" /> <br />
          <label> Status</label>
          <input type="text" name="status" placeholder={this.state.data.status} onChange={this.handleChange} className="form-control" /> <br />
          <label> Is Admin</label>
          <input type="text" name="isAdmin" placeholder={this.state.data.isAdmin} onChange={this.handleChange} className="form-control" /> <br />
        </form></div>
      </div>
      <div style={{marginLeft:"50px"}}>
        <button className="attr_btn ml-4 mr-5" onClick= {this.save} type="submit" >Save</button>
        
      </div>
    </div>

  </div>
  <div >
    <div >
      
 
   
    </div>

  </div>
</div>
            </>
        )
    }
}