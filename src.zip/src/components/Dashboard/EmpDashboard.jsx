import React, { Component } from "react";
import {Link} from 'react-router-dom'
// import axios from 'axios';
import ArrowForwardIosIcon from '@material-ui/icons/ArrowForwardIos';

export default class AdminDashboard extends Component{
    render(){
        return (
            <>
            <h1>Hi EMployee</h1>
            <Link to = "/">logout
            <ArrowForwardIosIcon></ArrowForwardIosIcon></Link>
            </>
        )
    }
}