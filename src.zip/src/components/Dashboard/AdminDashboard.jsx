import React, { Component } from "react";
import {Link} from 'react-router-dom'
// import axios from 'axios';

export default class AdminDashboard extends Component{
    render(){
        return (
            <>
            <h1>Hi admin</h1>
            <Link to = "/">logout</Link>
            </>
        )
    }
}